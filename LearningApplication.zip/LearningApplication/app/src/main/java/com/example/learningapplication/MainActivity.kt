package com.example.learningapplication


import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

//bAdapter = BluetoothAdapter
    lateinit var bAdapter:BluetoothAdapter


    const val REQUEST_CODE_ENABLE_BT:Int = 1

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvBluetoothState = findViewById<TextView>(R.id.tvBluetoothState)
        val ivBluetoothConnection = findViewById<ImageView>(R.id.ivBluetoothConnection)
        val btnBluetoothOn = findViewById<Button>(R.id.btnBluetoothOn)
        val btnBluetoothOff = findViewById<Button>(R.id.btnBluetoothOff)
        val btnPaired = findViewById<Button>(R.id.btnPaired)
        val tvPaired = findViewById<TextView>(R.id.tvPaired)

        bAdapter = BluetoothAdapter.getDefaultAdapter ()

        //Check if bluetooth is available or not
        tvBluetoothState.text = "Bluetooth is available"
        //set image according to bluetooth state (on/off)
        if (bAdapter.isEnabled) {
            //Bluetooth is on
            ivBluetoothConnection.setImageResource(R.drawable.ic_bluetooth_on)
        } else {
            //Bluetooth is off
            ivBluetoothConnection.setImageResource((R.drawable.ic_bluetooth_off))
        }

        //Check if bluetooth permissions have been granted
        if (ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.BLUETOOTH
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                android.Manifest.permission.BLUETOOTH_CONNECT
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "First enable BLUETOOTH in settings.", Toast.LENGTH_LONG)
                .show()
            return
        }

        //Turn bluetooth on
        btnBluetoothOn.setOnClickListener {
            if (bAdapter.isEnabled) {
                Toast.makeText(this, "Bluetooth is already on", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivityForResult(intent, REQUEST_CODE_ENABLE_BT)
            }
        }

        //Turn bluetooth off
        btnBluetoothOff.setOnClickListener {
            if (!bAdapter.isEnabled) {
                Toast.makeText(this, "Bluetooth is already off", Toast.LENGTH_SHORT).show()
            } else {
                bAdapter.disable()
                ivBluetoothConnection.setImageResource(R.drawable.ic_bluetooth_off)
                Toast.makeText(this, "Bluetooth is disabled", Toast.LENGTH_LONG).show()
            }
        }

        //Get list of paired devices
        btnPaired.setOnClickListener {
            if (bAdapter.isEnabled) {
                tvPaired.text = "Paired Devices:"
                //Get list of paired devices
                val devices = bAdapter.bondedDevices
                for (device in devices) {
                    val deviceName = device.name
                    val deviceAddress = device.address
                    tvPaired.append("\nDevice: $deviceName $deviceAddress")
                }
            }
            else {
                Toast.makeText(this, "Turn bluetooth on first", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        val ivBluetoothConnection = findViewById<ImageView>(R.id.ivBluetoothConnection)

        when(requestCode) {
            REQUEST_CODE_ENABLE_BT ->
                if (resultCode == Activity.RESULT_OK) {
                    ivBluetoothConnection.setImageResource(R.drawable.ic_bluetooth_on)
                    Toast.makeText(this, "Bluetooth enabled", Toast.LENGTH_SHORT).show()
                }
                else {
                    //User denied to turn bluetooth on from confirmation dialogue
                    Toast.makeText(this, "Couldn't enable bluetooth", Toast.LENGTH_SHORT).show()
                }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }
}
